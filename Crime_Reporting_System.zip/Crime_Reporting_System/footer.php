<div class="footer clear">
    	<span>Crime Reporting of Gujarat  � 2010  |  <a href="#">Privacy Policy</a></span> Crime Reporting is for registering FIR any time and any where in Gujarat released under HCL Info System.. &nbsp;&nbsp;&nbsp;<!--{%FOOTER_LINK} -->
    </div>
</div>
<!--osc3.template-help.com -->


</body></html>