<?
$username=$_GET['txtUserName'];
$pwd11=$_GET['pwd1'];
$pwd22=$_GET['pwd2'];
$emailid=$_GET['txtemailid'];
$addr=$_GET['trAddr'];
$dob=$_GET['d'];
$gender=$_GET['gender'];
$state=$_GET['salStateName'];
$hobbies=$_GET['chkHobbies'];


echo 'Username is ....'.$username."<br/>";
echo 'Password is....'.$pwd11."<br/>";
echo 'Confirm Password is....'.$pwd22."<br/>";
echo 'Ur Emailid is....'.$emailid."<br/>";
echo 'Ur address is....'.$addr."<br/>";
echo 'Ur date of birth is....'.$dob."<br/>";
echo 'U r ....'.$gender."<br/>";
echo 'State is....'.$state."<br/>";
echo 'Ur hobbies are....'.$hobbies."<br/>";
?>

