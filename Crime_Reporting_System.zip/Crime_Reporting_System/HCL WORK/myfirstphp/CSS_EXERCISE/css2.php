
<body>
<h1 style="background-color:#0000FF">Good Afternoon</h1>
</body>
</html>
