
<body>
<h1 style="background-color:#FF9999" > Welcome to new world <? echo $_GET["user"]?></h1>

<a href="viewuser.php"> View employees</a>

<? echo $_GET['name'];
echo $_GET['test'];
?>