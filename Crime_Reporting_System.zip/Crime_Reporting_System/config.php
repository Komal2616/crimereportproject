<?php
$conn = mysql_connect("127.0.0.1", "", "") or die("Error");
mysql_select_db("crime_portal") or die("Error in selecting database");
?>
